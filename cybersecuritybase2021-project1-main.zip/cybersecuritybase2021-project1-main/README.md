# cybersecuritybase2021-project1

Course project I for Cyber Security Base 2021, for more details see here: https://cybersecuritybase.mooc.fi/module-3.1

## Warning

The task of the project is to create a web application that has at least five different flaws from the OWASP top ten list.

So that being said **this project then will have multiple security issues** and should not in any circumstances be used on anything other than testing purposes in a safe environment.


